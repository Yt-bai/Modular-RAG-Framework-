from typing import List, Dict
import os


class BaseLLM:
    def generate(self, query: str, context: str, chat_history: List[Dict[str, str]] = None) -> str:
        raise NotImplementedError()


class FakeLLM(BaseLLM):
    def generate(self, query, context, chat_history=None):
        if not context.strip():
            return "根据提供的信息，我无法回答这个问题。"
        return f"【模拟回答】\n\n{context[:300]}"


class OllamaLLM(BaseLLM):
    def __init__(self, model="llama3"):
        from langchain_community.chat_models import ChatOllama
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.prompts import ChatPromptTemplate

        self.llm = ChatOllama(model=model, temperature=0.1)
        self.parser = StrOutputParser()

        self.prompt = ChatPromptTemplate.from_template(
            """请基于以下上下文回答问题：

{context}

问题：
{query}
"""
        )

    def generate(self, query, context, chat_history=None):
        chain = self.prompt | self.llm | self.parser
        return chain.invoke({"query": query, "context": context})


class OpenAICompatibleLLM(BaseLLM):
    def __init__(self, model, base_url, api_key_env):
        from langchain_openai import ChatOpenAI
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.prompts import ChatPromptTemplate

        key = os.getenv(api_key_env)
        if not key:
            raise ValueError(f"{api_key_env} 未设置")

        self.llm = ChatOpenAI(
            model=model,
            base_url=base_url,
            api_key=key,
            temperature=0.1
        )

        self.parser = StrOutputParser()

        self.prompt = ChatPromptTemplate.from_template(
            """请基于以下上下文回答问题：

{context}

问题：
{query}
"""
        )

    def generate(self, query, context, chat_history=None):
        chain = self.prompt | self.llm | self.parser
        return chain.invoke({"query": query, "context": context})


def get_llm(mode="fake"):
    """
    mode:
    - fake
    - ollama
    - aihubmix
    - openai
    - groq (同样可用 openai-compatible)
    """

    if mode == "fake":
        return FakeLLM()

    if mode == "ollama":
        return OllamaLLM(model="llama3")

    if mode == "aihubmix":
        return OpenAICompatibleLLM(
            model="你从models.list查到的正确模型ID",
            base_url="https://api.aihubmix.com/v1",
            api_key_env="AIHUBMIX_API_KEY"
        )

    raise ValueError("未知 LLM 模式")