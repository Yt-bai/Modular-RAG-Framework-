from langchain_core.embeddings import Embeddings
from typing import List
import hashlib


class SimpleEmbeddings(Embeddings):
    def __init__(self, dimension: int = 384):
        self.dimension = dimension

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self._embed_text(t) for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._embed_text(text)

    def _embed_text(self, text: str) -> List[float]:
        hash_bytes = hashlib.md5(text.encode()).digest()
        vector = []
        for i in range(self.dimension):
            byte_idx = i % len(hash_bytes)
            value = (hash_bytes[byte_idx] / 255.0) * 2 - 1
            vector.append(value)
        return vector


def get_embeddings(config):
    print("📊 使用 SimpleEmbeddings（离线模式）")
    return SimpleEmbeddings()