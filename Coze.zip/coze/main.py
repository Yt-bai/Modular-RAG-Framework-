import os
from config import RAGConfig
from document_loader import load_documents_from_dir, build_documents
from text_processor import split_documents
from vector_store import get_or_create_chroma
from retriever import Retriever
from generator import Generator
from rag_graph import build_graph

def main():
    print("=" * 60)
    print("🚀 RAG 检索增强生成系统演示（LangGraph + Chroma + Groq + HF Embeddings）")
    print("=" * 60)

    config = RAGConfig(
        chunk_size=300,
        chunk_overlap=50,
        top_k=3,
    )

    # 1) Load docs
    docs_dir = "./sample_docs"
    print("\n📄 加载 sample_docs 文档...")
    texts, metadatas = load_documents_from_dir(docs_dir)
    documents = build_documents(texts, metadatas)

    # 2) Split
    print("✂️  分割文档...")
    chunks = split_documents(documents, config)
    print(f"   生成了 {len(chunks)} 个文本块")

    # 3) Vector store (Chroma persist)
    vectordb = get_or_create_chroma(chunks, config)

    # 4) Components
    retriever = Retriever(vectordb, config)
    generator = Generator(config)
    graph = build_graph(retriever, generator)

    # 5) Single-turn demo
    print("\n" + "=" * 60)
    print("📝 示例 1：单轮问答")
    print("=" * 60)

    questions = [
        "什么是 LangChain？它有什么特点？",
        "RAG 系统的工作流程是怎样的？",
        "有哪些常见的向量数据库？",
    ]

    for q in questions:
        initial_state = {
            "query": q,
            "chat_history": [],
            "documents": [],
            "context": "",
            "answer": "",
            "sources": [],
            "confidence": 0.0,
        }
        result = graph.invoke(initial_state)
        print(f"\n📌 回答：\n{result['answer']}")
        print("\n📎 来源：")
        for src in result["sources"]:
            print(f"   - [{src['index']}] {src['source']}")
        print(f"\n📊 置信度：{result['confidence']:.2f}")
        print("-" * 60)

    # 6) Multi-turn demo
    print("\n" + "=" * 60)
    print("📝 示例 2：多轮对话（带上下文）")
    print("=" * 60)

    chat_history = []

    q1 = "LangGraph 是什么？"
    print(f"\n👤 用户：{q1}")
    r1 = graph.invoke({
        "query": q1,
        "chat_history": chat_history,
        "documents": [],
        "context": "",
        "answer": "",
        "sources": [],
        "confidence": 0.0,
    })
    print(f"\n🤖 助手：{r1['answer']}")
    chat_history.append({"role": "user", "content": q1})
    chat_history.append({"role": "assistant", "content": r1["answer"]})

    q2 = "它的核心概念有哪些？"
    print(f"\n👤 用户：{q2}")
    r2 = graph.invoke({
        "query": q2,
        "chat_history": chat_history,
        "documents": [],
        "context": "",
        "answer": "",
        "sources": [],
        "confidence": 0.0,
    })
    print(f"\n🤖 助手：{r2['answer']}")
    chat_history.append({"role": "user", "content": q2})
    chat_history.append({"role": "assistant", "content": r2["answer"]})

    q3 = "在什么场景下使用它比较合适？"
    print(f"\n👤 用户：{q3}")
    r3 = graph.invoke({
        "query": q3,
        "chat_history": chat_history,
        "documents": [],
        "context": "",
        "answer": "",
        "sources": [],
        "confidence": 0.0,
    })
    print(f"\n🤖 助手：{r3['answer']}")

    print("\n" + "=" * 60)
    print("✅ RAG 系统演示完成！")
    print("=" * 60)

if __name__ == "__main__":
    main()