from langgraph.graph import StateGraph, START, END
from state import RAGState


def build_graph(retriever, generator):
    """
    retriever: 有 retrieve(query) 方法
    generator: 有 generate(query, context, chat_history) 方法
    """

    def retrieve_documents(state: RAGState) -> RAGState:
        docs = retriever.retrieve(state["query"])
        state["documents"] = docs

        context_parts = []
        sources = []

        for i, doc in enumerate(docs):
            context_parts.append(f"[文档 {i+1}] {doc.page_content}")
            sources.append({
                "index": i + 1,
                "source": doc.metadata.get("source", "unknown"),
                "content_preview": (doc.page_content[:100] + "...") if len(doc.page_content) > 100 else doc.page_content
            })

        state["context"] = "\n\n".join(context_parts)
        state["sources"] = sources
        return state

    def generate_answer(state: RAGState) -> RAGState:
        state["answer"] = generator.generate(
            query=state["query"],
            context=state["context"],
            chat_history=state.get("chat_history", []),
        )
        return state

    graph = StateGraph(RAGState)
    graph.add_node("retrieve", retrieve_documents)
    graph.add_node("generate", generate_answer)

    graph.add_edge(START, "retrieve")
    graph.add_edge("retrieve", "generate")
    graph.add_edge("generate", END)

    return graph.compile()