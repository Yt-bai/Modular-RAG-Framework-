import os
from typing import List
from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from config import RAGConfig
from embeddings import get_embeddings


def get_or_create_chroma(docs: List[Document], config: RAGConfig) -> Chroma:
    embeddings = get_embeddings(config)

    os.makedirs(config.chroma_dir, exist_ok=True)

    vectordb = Chroma(
        collection_name=config.chroma_collection,
        persist_directory=config.chroma_dir,
        embedding_function=embeddings,
    )

    try:
        existing = vectordb._collection.count()
    except Exception:
        existing = 0

    if existing and existing > 0:
        print(f"📦 检测到已有 Chroma 索引：{existing} 条")
        return vectordb

    print("🔢 创建 Chroma 向量库并写入文档...")
    vectordb.add_documents(docs)
    vectordb.persist()
    print("✅ Chroma 向量库构建完成")
    return vectordb