from typing import List, Tuple
from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from config import RAGConfig

class Retriever:
    def __init__(self, vector_store: Chroma, config: RAGConfig):
        self.vector_store = vector_store
        self.config = config

    def retrieve(self, query: str) -> List[Document]:
        return self.vector_store.similarity_search(query=query, k=self.config.top_k)

    def retrieve_with_scores(self, query: str) -> List[Tuple[Document, float]]:
        return self.vector_store.similarity_search_with_score(query=query, k=self.config.top_k)