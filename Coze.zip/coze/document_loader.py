import os
from typing import List, Dict, Optional, Tuple
from langchain_core.documents import Document

def load_documents_from_dir(
    docs_dir: str,
    encoding: str = "utf-8"
) -> Tuple[List[str], List[Dict]]:
    """
    读取 sample_docs 下的 .txt 文件，返回 texts + metadatas
    """
    texts: List[str] = []
    metadatas: List[Dict] = []

    for fname in sorted(os.listdir(docs_dir)):
        if not fname.endswith(".txt"):
            continue
        path = os.path.join(docs_dir, fname)
        with open(path, "r", encoding=encoding) as f:
            texts.append(f.read())
        metadatas.append({"source": fname})

    return texts, metadatas


def build_documents(texts: List[str], metadatas: Optional[List[Dict]] = None) -> List[Document]:
    docs: List[Document] = []
    for i, text in enumerate(texts):
        md = metadatas[i] if metadatas and i < len(metadatas) else {"source": f"doc_{i}"}
        docs.append(Document(page_content=text, metadata=md))
    return docs