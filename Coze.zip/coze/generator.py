from llm_factory import get_llm
from config import RAGConfig


class Generator:
    def __init__(self, config: RAGConfig):
        self.config = config
        self.llm = get_llm(mode="fake")  # 这里可以切换

    def generate(self, query, context, chat_history=None):
        return self.llm.generate(query, context, chat_history)