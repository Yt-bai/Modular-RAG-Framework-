import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

# 你现在用 AIHubMix，不再强制 Groq
AIHUBMIX_API_KEY = os.getenv("AIHUBMIX_API_KEY")


@dataclass
class RAGConfig:
    # chunking
    chunk_size: int = 500
    chunk_overlap: int = 100

    # retrieval
    top_k: int = 3
    search_type: str = "similarity"

    # generation
    temperature: float = 0.1
    max_tokens: int = 1000  # 预留

    # storage
    chroma_dir: str = "./chroma_db"
    chroma_collection: str = "rag_docs"

    # embeddings (offline)
    # 你现在用 SimpleEmbeddings，可保留字段但不必用
    hf_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # LLM (AIHubMix)
    aihubmix_model: str = "gemini-3-flash-preview-free"
    aihubmix_base_url: str = "https://api.aihubmix.com/v1"